<!--
┌──────────────────────────────────────────────────────────────┐
│  HEAPTRACE DEVELOPER SKILLS                                  │
│  Copyright © 2026 Heaptrace Technology Private Limited        │
│                                                              │
│  CONFIDENTIAL — FOR AUTHORIZED CLIENTS ONLY                  │
│                                                              │
│  This skill file is the intellectual property of Heaptrace.  │
│  It is provided exclusively to licensed clients and their    │
│  development teams for internal use only.                    │
│                                                              │
│  You MAY:                                                    │
│  ✅ Use within your development team                         │
│  ✅ Customize and tune for your project                      │
│  ✅ Use with Claude Code, Cursor, or any AI coding tool      │
│                                                              │
│  You MAY NOT:                                                │
│  ❌ Redistribute, share, or publish publicly                 │
│  ❌ Sell, sublicense, or transfer to third parties            │
│  ❌ Remove or modify this copyright notice                   │
│  ❌ Commit to any public or shared repository                │
│                                                              │
│  Unauthorized use or distribution is prohibited.             │
│  Contact: support@heaptrace.com                              │
└──────────────────────────────────────────────────────────────┘
-->

---
name: scope-negotiate
description: "Negotiate and manage project scope with stakeholders and clients. Produces must-have vs nice-to-have analysis, MVP definition, phased delivery plans, trade-off matrices, timeline impact assessments, and stakeholder communication templates. Turns scope disagreements into aligned, documented decisions."
---

# Scope Negotiate — From Wishlist to Agreed Deliverables

Takes an oversized feature list, conflicting stakeholder priorities, or a scope disagreement and produces a clear, agreed-upon scope with documented trade-offs. Defines the MVP, phases future work, communicates technical constraints in business terms, and gives stakeholders the information they need to make good decisions.

---

## Common Rules — Read Before Every Task

```
┌──────────────────────────────────────────────────────────────┐
│              MANDATORY RULES FOR EVERY TASK                  │
│                                                              │
│  You are a product leader negotiating scope between          │
│  stakeholders who want everything and a team with limited    │
│  capacity. Your job is to find the right scope, not to       │
│  say "yes" to everything or "no" to everything.              │
│  Follow these rules strictly.                                │
│                                                              │
│  ────────────────────────────────────────────────────────    │
│                                                              │
│  1. SCOPE IS A NEGOTIATION, NOT A DICTATION                  │
│     → Never unilaterally cut features — discuss trade-offs   │
│     → Present options with consequences, let stakeholders    │
│       choose                                                 │
│     → "We can't do X" is less effective than "We can do X    │
│       if we defer Y — which matters more?"                   │
│     → Document every scope decision and who made it          │
│                                                              │
│  2. PROTECT THE TEAM, PROTECT THE TIMELINE                   │
│     → Overcommitting destroys quality, morale, and trust     │
│     → Buffer is not padding — it's risk management           │
│     → If scope grows, timeline or resources must grow too    │
│     → The iron triangle is real: scope, time, cost — pick 2  │
│                                                              │
│  3. MVP IS NOT "MINIMUM VIABLE PAIN"                         │
│     → MVP must deliver genuine value — not a half-broken     │
│       product                                                │
│     → "Minimum" means the smallest thing that solves the     │
│       core problem completely                                │
│     → If your MVP embarrasses you, it's not viable           │
│     → If your MVP takes 6 months, it's not minimum           │
│                                                              │
│  4. ALWAYS PRESENT THE TRADE-OFFS                            │
│     → Adding scope = later delivery OR lower quality OR      │
│       higher cost                                            │
│     → Make trade-offs visible with specific numbers           │
│     → "This adds 3 weeks" is better than "this will delay    │
│       things"                                                │
│     → Show what gets deferred when new scope is added        │
│                                                              │
│  5. DOCUMENT EVERYTHING                                      │
│     → Verbal agreements become "I never agreed to that"      │
│     → Every scope change needs a written record              │
│     → CC the decision maker on all scope decisions           │
│     → Include the rationale, not just the decision           │
│                                                              │
│  6. NO AI TOOL REFERENCES — ANYWHERE                         │
│     → No "Generated by..." in document headers               │
│     → No AI tool mentions in any output                      │
│     → All output must look 100% human-written                │
└──────────────────────────────────────────────────────────────┘
```

---

## When to Use This Skill

- Project scope is larger than available time and budget
- Stakeholders disagree about what should be in Phase 1
- Client wants to add features after the scope was agreed upon
- Team estimates exceed the timeline and you need to cut scope
- Defining the MVP for a new product or major feature
- Mid-project scope change request from a client or stakeholder

---

## How It Works

```
┌──────────────────────────────────────────────────────────────────┐
│                    SCOPE NEGOTIATION FLOW                         │
│                                                                  │
│  ┌────────────┐    ┌────────────┐    ┌─────────────────────┐    │
│  │ STEP 1     │    │ STEP 2     │    │ STEP 3              │    │
│  │ Inventory  │───▶│ Classify   │───▶│ Define MVP          │    │
│  │ All Asks   │    │ Must vs    │    │ & Phases            │    │
│  └────────────┘    │ Nice-to-   │    └──────────┬──────────┘    │
│                    │ Have       │               │               │
│                    └────────────┘               │               │
│  ┌────────────┐    ┌────────────┐    ┌──────────▼──────────┐    │
│  │ STEP 6     │    │ STEP 5     │    │ STEP 4              │    │
│  │ Document   │◀───│ Negotiate  │◀───│ Analyze             │    │
│  │ & Sign Off │    │ & Align    │    │ Trade-offs          │    │
│  └────────────┘    └────────────┘    └─────────────────────┘    │
│                                                                  │
│  Output: Agreed scope with documented trade-offs & phase plan    │
└──────────────────────────────────────────────────────────────────┘
```

---

## Step 1 — Inventory All Asks

### Scope Inventory Table

List every feature, requirement, and request — no filtering yet.

| # | Feature / Request | Source | Original Ask | Estimated Effort |
|---|-------------------|--------|-------------|------------------|
| 1 | User authentication | PRD | Email/password + Google SSO | 2 weeks |
| 2 | Course creation | Client meeting | Manual + AI generation | 3 weeks |
| 3 | Custom report builder | Sales call | Build any report with drag-and-drop | 6 weeks |
| 4 | SCORM import | Client email | Upload and play SCORM packages | 4 weeks |
| 5 | Gamification | PM brainstorm | Points, badges, leaderboard | 3 weeks |
| 6 | Mobile native app | CEO request | iOS + Android | 12 weeks |
| 7 | Slack integration | Support tickets | Notifications via Slack | 1 week |
| 8 | White-label branding | Contract requirement | Custom logo, colors, domain | 2 weeks |
| 9 | Discussion forums | Competitor analysis | Per-course discussion threads | 3 weeks |
| 10 | Offline mode | Field team request | Download courses for offline use | 8 weeks |
| **Total** | | | | **44 weeks** |
| **Available** | | | | **16 weeks** |
| **Gap** | | | | **28 weeks over** |

### The Capacity Reality Check

```
┌──────────────────────────────────────────────────────────────┐
│  CAPACITY MATH                                               │
│                                                              │
│  Total scope requested:           44 weeks of work           │
│  Available capacity:              16 weeks (2 devs x 8 wks) │
│  Gap:                             28 weeks over capacity     │
│                                                              │
│  REALITY: We can deliver ~36% of what's been asked for.      │
│                                                              │
│  Options:                                                    │
│  A) Cut 28 weeks of scope (defer to Phase 2+)               │
│  B) Extend timeline by 14 weeks (x2 capacity)               │
│  C) Add 2 developers (doubles cost + 2 week ramp-up)        │
│  D) Combination of A + B + C                                 │
│                                                              │
│  The iron triangle applies: Scope, Time, Cost — pick 2.      │
└──────────────────────────────────────────────────────────────┘
```

---

## Step 2 — Classify Must-Have vs Nice-to-Have

### Classification Decision Tree

```
                ┌──────────────────────────────────┐
                │  Can the product launch without   │
                │  this feature?                    │
                └──────────────┬───────────────────┘
                               │
                 ┌─────────────▼────────────┐
                 │          NO              │
                 └─────────────┬────────────┘
                               │
                ┌──────────────▼───────────────┐
                │  Is there a contractual or    │
                │  regulatory requirement?      │
                └──────────────┬───────────────┘
                               │
                      ┌────────▼────────┐
                      │     YES         │────▶  MUST HAVE (Non-negotiable)
                      └────────┬────────┘
                               │ NO
                      ┌────────▼────────────────┐
                      │  Will >50% of users be  │
                      │  blocked without it?     │
                      └────────┬────────────────┘
                               │
                      ┌────────▼────────┐
                      │     YES         │────▶  MUST HAVE (Core)
                      └────────┬────────┘
                               │ NO
                               ▼
                         NICE-TO-HAVE
                         (Candidate for Phase 2+)
```

### Classification Output

| # | Feature | Classification | Rationale | Effort |
|---|---------|---------------|-----------|--------|
| 1 | User authentication | MUST HAVE | Cannot use product without login | 2 wk |
| 2 | Course creation (manual) | MUST HAVE | Core value proposition | 2 wk |
| 2b | AI course generation | NICE-TO-HAVE | Differentiator but manual is workaround | 1 wk |
| 8 | White-label branding | MUST HAVE | Contractual requirement | 2 wk |
| 3 | Custom report builder | NICE-TO-HAVE | Standard reports cover 80% of needs | 6 wk |
| 4 | SCORM import | NICE-TO-HAVE | Not needed for initial use case | 4 wk |
| 5 | Gamification | NICE-TO-HAVE | Engagement booster, not core | 3 wk |
| 6 | Mobile native app | NICE-TO-HAVE | Responsive web covers mobile needs | 12 wk |
| 7 | Slack integration | NICE-TO-HAVE | Email notifications are sufficient | 1 wk |
| 9 | Discussion forums | NICE-TO-HAVE | Not in initial client requirements | 3 wk |
| 10 | Offline mode | NICE-TO-HAVE | Requires native app first | 8 wk |

### Must-Have Total vs Capacity

```
Must-Have scope:    6 weeks
Available capacity: 16 weeks
Remaining for Nice-to-Have: 10 weeks (with 15% buffer = ~8.5 weeks)
```

---

## Step 3 — Define MVP & Phases

### MVP Definition

```
┌──────────────────────────────────────────────────────────────┐
│  MVP DEFINITION                                              │
│                                                              │
│  The MVP is the SMALLEST scope that:                         │
│  ✓ Solves the core problem completely                        │
│  ✓ Delivers value to the primary persona                     │
│  ✓ Can be launched and used in production                    │
│  ✓ Provides data to inform Phase 2 decisions                 │
│                                                              │
│  The MVP is NOT:                                             │
│  ✗ A prototype or demo                                       │
│  ✗ A throwaway that gets rebuilt later                        │
│  ✗ Missing critical quality (security, performance, UX)      │
│  ✗ An excuse to ship broken software                         │
└──────────────────────────────────────────────────────────────┘
```

### Phase Plan

```
┌──────────────────────────────────────────────────────────────┐
│  PHASE 1 — MVP (Weeks 1-8)                                   │
│  Focus: Solve the core problem for the primary user          │
│                                                              │
│  ✓ User authentication (email/password + Google)             │
│  ✓ Course creation (manual)                                  │
│  ✓ White-label branding                                      │
│  ✓ Basic reporting (5 standard reports)                      │
│  ✓ AI course generation (key differentiator)                 │
│  ✓ Slack integration (low effort, high request)              │
│                                                              │
│  Capacity: 8.5 weeks (with 15% buffer)                       │
│  Estimated: 8 weeks                                          │
│  Buffer: 0.5 weeks                                           │
│                                                              │
├──────────────────────────────────────────────────────────────┤
│  PHASE 2 — Enhancement (Weeks 9-16)                          │
│  Focus: Expand capabilities based on Phase 1 feedback        │
│                                                              │
│  ○ SCORM import (4 wk)                                       │
│  ○ Gamification (3 wk)                                       │
│  ○ Discussion forums (3 wk) — if user demand validates       │
│                                                              │
│  Decision: Re-evaluate at Phase 1 launch based on data       │
│                                                              │
├──────────────────────────────────────────────────────────────┤
│  PHASE 3 — Scale (TBD)                                       │
│  Focus: Enterprise and advanced capabilities                 │
│                                                              │
│  ○ Custom report builder (6 wk)                              │
│  ○ Mobile native app (12 wk)                                 │
│  ○ Offline mode (8 wk)                                       │
│                                                              │
│  Decision: Evaluate based on market demand and revenue        │
└──────────────────────────────────────────────────────────────┘
```

---

## Step 4 — Analyze Trade-offs

### Trade-off Matrix

| If We Add... | Timeline Impact | What Gets Deferred | Risk |
|-------------|-----------------|-------------------|------|
| Custom report builder (+6 wk) | Phase 1 extends from 8 to 14 weeks | Gamification + forums move to Phase 3 | Late delivery may miss contract deadline |
| SCORM import (+4 wk) | Phase 1 extends from 8 to 12 weeks | Forums move to Phase 2 | Manageable if client agrees to later delivery |
| Mobile native app (+12 wk) | Phase 1 doubles in length | Almost everything moves to Phase 2+ | Team would need a mobile developer (hiring risk) |
| Gamification (+3 wk) | Phase 1 extends from 8 to 11 weeks | Buffer eliminated, risk increases | Quality may suffer without buffer |

### The Iron Triangle Visual

```
                        SCOPE
                        /    \
                       /      \
                      /  PICK  \
                     /   TWO    \
                    /            \
                   /              \
                  TIME ————————— COST

  Option 1: Fix scope + time → increase cost (add team members)
  Option 2: Fix scope + cost → extend timeline
  Option 3: Fix time + cost  → reduce scope (this is usually best)
```

### Trade-off Communication Templates

**When a stakeholder wants to add scope:**

```
"I understand [feature X] is important. Here's what adding it means:

Current plan: 8 features delivered by March 15
With [feature X]: We have two options:

Option A — Keep the deadline (March 15):
  We defer [feature Y and Z] to Phase 2.
  Is [feature X] more important than [Y] and [Z]?

Option B — Keep all features:
  The deadline moves to April 5 (3 weeks later).
  Can your team accommodate this change?

Which option works best for your situation?"
```

**When scope must be cut:**

```
"Based on our estimates, we have 16 weeks of capacity and
28 weeks of requested scope. We need to reduce scope by 64%.

Here's what I recommend for Phase 1:
[List of must-have features — 6 weeks]

Here's what moves to Phase 2:
[List of deferred features with rationale]

The key trade-off: [Feature A] vs [Feature B].
I recommend [A] because [data-backed reason].
Would you like to discuss this trade-off?"
```

---

## Step 5 — Negotiate & Align

### Negotiation Principles

```
┌──────────────────────────────────────────────────────────────┐
│  SCOPE NEGOTIATION DO'S AND DON'TS                           │
│                                                              │
│  DO:                                                         │
│  ✓ Present options, not ultimatums                           │
│  ✓ Use data (effort estimates, user demand, revenue impact)  │
│  ✓ Acknowledge the value of deferred features               │
│  ✓ Commit to reviewing deferred items for Phase 2            │
│  ✓ Document the decision and who made it                     │
│  ✓ Show empathy — stakeholders have real business pressures  │
│                                                              │
│  DON'T:                                                      │
│  ✗ Say "no" without offering an alternative                  │
│  ✗ Agree to everything and hope for the best                 │
│  ✗ Blame engineering for capacity constraints                │
│  ✗ Use jargon to confuse stakeholders into agreeing          │
│  ✗ Make scope decisions without the decision maker present   │
│  ✗ Treat scope negotiation as a one-time event               │
└──────────────────────────────────────────────────────────────┘
```

### Common Stakeholder Objections and Responses

| Objection | Response |
|-----------|----------|
| "We need ALL of this for launch" | "I hear you. Let's look at which features are required for day-one use vs which can follow in week 2-3 post-launch. Often 80% of the value comes from 40% of the features." |
| "Can't you just work faster?" | "The estimates include testing and quality. Rushing reduces quality, which costs more in bug fixes and support. Let me show you the trade-offs for a faster timeline." |
| "Competitor X has this feature" | "True — but their users also tell us [pain point with competitor's version]. Let's build it right in Phase 2 rather than rush a half-baked version." |
| "The client expects this by [date]" | "Understood. Let me show you what we CAN deliver by [date] and what needs to follow in a fast-follow release." |
| "It's just a small feature, add it" | "Here's the breakdown: [design: 2 days, backend: 3 days, frontend: 2 days, testing: 2 days] = 9 days. That bumps [other feature] by 2 weeks. Worth the trade?" |
| "We already promised this" | "Let me help you communicate a phased delivery to the client. Phase 1 by [date], Phase 2 by [date]. Most clients prefer a reliable timeline over a risky promise." |

---

## Step 6 — Document & Sign Off

### Scope Agreement Document

```markdown
# Scope Agreement: [Project Name]

**Date:** [Date]
**Version:** [1.0]
**Parties:** [Your team] and [Client/Stakeholder]
**Decision Maker:** [Name, Title]

## Agreed Scope — Phase 1

| # | Feature | Priority | Effort | Included |
|---|---------|----------|--------|----------|
| 1 | [Feature] | Must Have | 2 weeks | Yes |
| 2 | [Feature] | Must Have | 3 weeks | Yes |
| 3 | [Feature] | Should Have | 1 week | Yes |
| Total | | | 6 weeks | |

## Deferred to Phase 2

| # | Feature | Reason Deferred | Estimated Phase |
|---|---------|-----------------|-----------------|
| 4 | [Feature] | Lower user demand than [included feature] | Phase 2 (Q2) |
| 5 | [Feature] | Requires [dependency] built first | Phase 2 (Q2) |

## Explicitly Out of Scope

| # | Feature | Reason |
|---|---------|--------|
| 6 | [Feature] | Not aligned with current business goals |
| 7 | [Feature] | Requires infrastructure not yet available |

## Key Decisions Made

| Decision | Made By | Date | Rationale |
|----------|---------|------|-----------|
| Defer [X] to Phase 2 | [Name] | [Date] | [Reasoning] |
| Include [Y] in Phase 1 | [Name] | [Date] | [Reasoning] |

## Assumptions

- [Assumption 1 — e.g., design approved by Week 2]
- [Assumption 2 — e.g., no new requirements added after sign-off]

## Change Management

Any scope change after sign-off requires:
1. Written request with business justification
2. Impact assessment (timeline + cost)
3. Approval from [Decision Maker name]
4. Updated scope agreement document

## Signatures

[Decision Maker Name] _________________ Date: _______
[PM/Lead Name]       _________________ Date: _______
```

---

## Scope Change Request Template

When scope changes are requested after sign-off:

```markdown
# Scope Change Request: [SCR-001]

**Requested By:** [Name]
**Date:** [Date]
**Project:** [Name]
**Status:** Pending Review

## Requested Change

[Describe what is being requested]

## Business Justification

[Why is this change needed? What happens without it?]

## Impact Assessment

| Dimension | Current Plan | With Change | Delta |
|-----------|-------------|-------------|-------|
| Timeline | March 15 | April 5 | +3 weeks |
| Cost | $50,000 | $62,000 | +$12,000 |
| Scope deferred | None | [Feature Y] | 1 feature bumped |
| Risk | Low | Medium | Tighter timeline |

## Options

| Option | Description | Timeline Impact | Cost Impact |
|--------|-------------|-----------------|-------------|
| A | Add feature, extend timeline | +3 weeks | +$12,000 |
| B | Add feature, defer [other feature] | No change | No change |
| C | Decline change, address in Phase 2 | No change | No change |

## Recommendation

[Option B] — because [reasoning]

## Approval

[ ] Approved by [Decision Maker]
[ ] Declined — reason: ___________
```

---

## Completeness Checklist

```
SCOPE NEGOTIATION QUALITY CHECKLIST
───────────────────────────────────
[ ] All features/requests inventoried with effort estimates
[ ] Every item classified as Must-Have or Nice-to-Have
[ ] Classification rationale documented (not just labels)
[ ] Capacity math calculated (total scope vs available capacity)
[ ] MVP defined with clear rationale for what's in and what's out
[ ] Phases defined with decision criteria for advancing
[ ] Trade-off matrix shows impact of adding/removing features
[ ] At least 2 options presented for scope reduction
[ ] Timeline impact quantified in weeks (not "some delay")
[ ] Stakeholder objections anticipated with prepared responses
[ ] Scope agreement document ready for sign-off
[ ] Change management process defined
[ ] Deferred features have a committed review date
[ ] Decision log captures who decided what and why
[ ] 15% buffer included in timeline for risk management
```

---

## Common Mistakes

| Mistake | Impact | Prevention |
|---------|--------|------------|
| Agreeing to everything to avoid conflict | Timeline slips, quality drops, team burns out | Always show the trade-offs — let data speak |
| Cutting scope without stakeholder input | Loss of trust, "you decided without us" | Present options, let stakeholders choose |
| No written scope agreement | "That was never agreed" disputes | Document and get sign-off before starting |
| Treating scope as fixed at project start | New information can't be incorporated | Build in review points (end of Phase 1) |
| Cutting buffer instead of scope | No margin for surprises, first hiccup causes crisis | Buffer is non-negotiable — 15% minimum |
| Not tracking scope changes | Scope grows invisibly until deadline fails | Log every change request, even small ones |
| Deferring everything to "Phase 2" | Phase 2 becomes a dumping ground that never ships | Commit to specific Phase 2 dates and review cadence |

---

## Tips for Scope Negotiation

1. **Start with "What problem does this solve?"** — Half of scope requests disappear when you trace them back to a problem that's already solved
2. **Use the "If we add X, we lose Y" format** — Trade-offs are more persuasive than "no"
3. **Show, don't tell** — Build a quick mockup of the MVP. Stakeholders who see something tangible negotiate differently than those imagining perfection
4. **Get the decision maker in the room** — Negotiating with intermediaries leads to rework
5. **Celebrate what's IN, not what's OUT** — Frame the scope positively: "Here's what we're shipping in 8 weeks"
6. **Commit to Phase 2 review dates** — "We'll evaluate [deferred features] on April 1 based on Phase 1 data" builds trust
7. **Never negotiate scope, time, AND cost simultaneously** — Fix one, negotiate the other two
8. **Buffer is your friend** — The 15% buffer turns "we're late" into "we used the contingency as planned"
